import os
import time
from datetime import datetime
import pandas as pd
import yfinance as yf
from ta.trend import SMAIndicator
from telegram import Bot
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
logger = logging.getLogger("raketradar")

TICKERS = os.getenv('TICKERS', 'NVDA,PLTR,AMD,SMCI,TALK')
TICKERS = [t.strip().upper() for t in TICKERS.split(',') if t.strip()]
CHECK_INTERVAL_SECONDS = int(os.getenv('CHECK_INTERVAL_SECONDS', '3600'))
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN', '')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')
LOG_CSV = os.getenv('LOG_CSV', '/app/data/raketradar_log.csv')
MA_WINDOW = int(os.getenv('MA_WINDOW', '20'))
VOL_WINDOW = int(os.getenv('VOL_WINDOW', '20'))

if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
    logger.error("TELEGRAM_TOKEN eller TELEGRAM_CHAT_ID ikke sat i env. Afslutter.")
    raise SystemExit("Telegram credentials mangler")

bot = Bot(token=TELEGRAM_TOKEN)

def send_telegram(text):
    try:
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=text)
        logger.info("Telegram sendt: %s", text[:120])
    except Exception as e:
        logger.exception("Fejl ved sending af Telegram: %s", e)

def get_intraday_df(ticker, period="10d", interval="60m"):
    try:
        d = yf.download(tickers=ticker, period=period, interval=interval, progress=False, threads=False)
        d.dropna(inplace=True)
        return d
    except Exception as e:
        logger.exception("Fejl ved hent af data for %s: %s", ticker, e)
        return pd.DataFrame()

def analyze_ticker(ticker):
    df = get_intraday_df(ticker, period="10d", interval="60m")
    if df.empty or len(df) < max
